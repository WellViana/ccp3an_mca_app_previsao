package br.usjt.app_previsoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPrevisoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
