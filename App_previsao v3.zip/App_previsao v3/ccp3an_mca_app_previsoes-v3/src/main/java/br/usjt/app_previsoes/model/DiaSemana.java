package br.usjt.app_previsoes.model;

public class DiaSemana {

}
