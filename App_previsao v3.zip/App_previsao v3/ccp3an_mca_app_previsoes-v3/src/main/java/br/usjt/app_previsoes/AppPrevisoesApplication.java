package br.usjt.app_previsoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPrevisoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppPrevisoesApplication.class, args);
	}

}
