insert into Previsao(id, diaSemana, min, max, humidade, descricao, data, hora, latitude, longitude) values (1, 'Terça-Feira', 26.0, 31.9, 57, 'Sol. Pancadas de chuva a qualquer hora do dia.', '2020-03-31', '15:45', '27° 35 49 Sul', '48° 32 58 Oeste');
insert into Previsao(id, diaSemana, min, max, humidade, descricao, data, hora, latitude, longitude) values (2, 'Quarta-Feira', 21.7, 28.7, 65, 'Sol com pancadas de chuva à tarde.', '2020-04-01', '07:00', '27° 35 49 Sul', '48° 32 58 Oeste');
insert into Previsao(id, diaSemana, min, max, humidade, descricao, data, hora, latitude, longitude) values (3, 'Quinta-Feira', 20.1, 25.0, 64, 'Dia nublado, sem previsão de chuva.', '2020-04-02', '09:00', '27° 35 49 Sul', '48° 32 58 Oeste');


insert into usuario (id, login, senha) values (1, 'admin@usjt.com', '123456')